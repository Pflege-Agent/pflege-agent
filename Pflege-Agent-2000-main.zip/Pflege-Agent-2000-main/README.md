# Pflege-Agent-2000
KI-Agent zur Erstellung von Pflegeberichten
